package co.msingh.android.fine;

import android.content.Context;
import android.database.Cursor;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import co.msingh.android.fine.views.EmotionListViewItem;
import co.msingh.android.fine.views.FlatColorListWithSwipeView;

/**
 * Created by mani on 07/03/15.
 */
public class AdapterNewEntry extends CursorAdapter {
    public AdapterNewEntry(Context context, Cursor cursor, int flags) {
        super(context, cursor, flags);
        height = 0;
    }

    private int height;

    public void setHeight(int h) {
        this.height = h;
//        Log.d(Generic.LOG_TAG, "height is: "+h);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(R.layout.emotion_list_item, parent, false);

//        view.setLayoutParams(new LinearLayout.LayoutParams(view.getWidth(), height));
        view.setMinimumHeight(height);

        int position = cursor.getPosition();
        FlatColorListWithSwipeView flatColorListWithSwipeView = (FlatColorListWithSwipeView) parent;

        ((EmotionListViewItem) view).setFlatColor(flatColorListWithSwipeView.getFlatColor(position));

//        view.setBackgroundColor(context.getResources().getColor(R.color.flat_white));


//        ((TextView)view.findViewById(R.id.list_item_emotion_textview))
//                .setTextColor(flatColorListWithSwipeView.getColor(position));

        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        int id = cursor.getInt(FragmentNewEntry.COLUMN_EMOTION_ID);
        String name = cursor.getString(FragmentNewEntry.COLUMN_EMOTION_NAME);
        int parentId = cursor.getInt(FragmentNewEntry.COLUMN_EMOTION_PARENT_ID);

//        String value = id+" - "+name+ " :parent-> "+parentId;
//        Log.d(Generic.LOG_TAG, "adding item to list: "+value);

        ((TextView) view.findViewById(R.id.list_item_emotion_textview)).setText(name);

        ((EmotionListViewItem) view).setEmotionId(id);
    }
}

package co.msingh.android.fine.views;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

import co.msingh.android.fine.R;
import co.msingh.android.fine.utilities.Colors;

/**
 * Created by mani on 11/03/15.
 */
public class EntryListViewItem extends CustomListViewItemBase implements CustomListViewItemBase.FlatColorSettings {

    private int entryId;
    private Colors.FlatColor color;

    public EntryListViewItem(Context context) {
        super(context);
    }

    public EntryListViewItem(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public EntryListViewItem(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public EntryListViewItem(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    public void setEntryId(int id) {
        this.entryId = id;
    }

    public int getEntryId() {
        return this.entryId;
    }

    @Override
    public void setFlatColor(Colors.FlatColor color) {
        this.color = color;
        normBackground();
    }

    public Colors.FlatColor getFlatColor() {
        return this.color;
    }

    public void normBackground() {
        if (this.color == null) return;
//        this.setBackgroundColor(this.color.getColor());
        ((TextView) this.findViewById(R.id.textView_entry_list_emotion_name)).setTextColor(getResources().getColor(color.getColor()));
        ((TextView) this.findViewById(R.id.textView_entry_list_date)).setTextColor(getResources().getColor(color.getAltColor()));

        this.findViewById(R.id.divider).setBackgroundColor(getResources().getColor(color.getAltColor()));
    }


}

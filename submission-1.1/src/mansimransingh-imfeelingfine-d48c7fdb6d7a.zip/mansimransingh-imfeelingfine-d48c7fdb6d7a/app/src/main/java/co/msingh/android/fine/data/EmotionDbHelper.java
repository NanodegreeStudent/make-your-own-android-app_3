package co.msingh.android.fine.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import co.msingh.android.fine.data.EmotionContract.EmotionEntry;
import co.msingh.android.fine.data.EmotionContract.Emotions;

/**
 * Manages a local database for weather data.
 */
public class EmotionDbHelper extends SQLiteOpenHelper {

    // If you change the database schema, you must increment the database version.
    private static final int DATABASE_VERSION = 1;

    public static final String DATABASE_NAME = "emotions.db";

    public EmotionDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        final String SQL_CREATE_EMOTIONS_TABLE = "CREATE TABLE " + Emotions.TABLE_NAME +
                " ( " +
                Emotions._ID + " INTEGER PRIMARY KEY, " +
                Emotions.COLUMN_EMOTION_NAME + " TEXT NOT NULL, " +
                Emotions.COLUMN_EMOTION_PARENT_ID + " INTEGER NULL " +
                " ); ";

        final String SQL_ADD_EMOTIONS_TO_TABLE = "INSERT INTO " + Emotions.TABLE_NAME +
                " (" + Emotions.COLUMN_EMOTION_NAME + ", " +
                Emotions.COLUMN_EMOTION_PARENT_ID + ", " +
                Emotions._ID + ") VALUES" +
                "('fear', 0, 1)," +
                "('anger', 0, 2)," +
                "('disgust', 0, 3)," +
                "('sad', 0, 4)," +
                "('happy', 0, 5)," +
                "('surprise', 0, 6)," +
                "('humiliated', 1, 7)," +
                "('rejected', 1, 8)," +
                "('submissive', 1, 9)," +
                "('insecure', 1, 10)," +
                "('anxious', 1, 11)," +
                "('scared', 1, 12)," +
                "('hurt', 2, 13)," +
                "('threatened', 2, 14)," +
                "('hateful', 2, 15)," +
                "('mad', 2, 16)," +
                "('aggressive', 2, 17)," +
                "('frustrated', 2, 18)," +
                "('distant', 2, 19)," +
                "('critical', 2, 20)," +
                "('disapproval', 3, 21)," +
                "('disappointed', 3, 22)," +
                "('awful', 3, 23)," +
                "('avoidance', 3, 24)," +
                "('guilty', 4, 25)," +
                "('abandoned', 4, 26)," +
                "('despair', 4, 27)," +
                "('depressed', 4, 28)," +
                "('lonely', 4, 29)," +
                "('bored', 4, 30)," +
                "('optimistic', 5, 31)," +
                "('intimate', 5, 32)," +
                "('peaceful', 5, 33)," +
                "('powerful', 5, 34)," +
                "('accepted', 5, 35)," +
                "('proud', 5, 36)," +
                "('interested', 5, 37)," +
                "('joyful', 5, 38)," +
                "('excited', 6, 39)," +
                "('amazed', 6, 40)," +
                "('confused', 6, 41)," +
                "('startled', 6, 42)," +
                "('ridiculed', 7, 43)," +
                "('disrespected', 7, 44)," +
                "('alienated', 8, 45)," +
                "('inadequate', 8, 46)," +
                "('insignificant', 9, 47)," +
                "('worthless', 9, 48)," +
                "('inferior', 10, 49)," +
                "('inadequate', 10, 50)," +
                "('worried', 11, 51)," +
                "('overwhelmed', 11, 52)," +
                "('frightened', 12, 53)," +
                "('terrified', 12, 54)," +
                "('devastated', 13, 55)," +
                "('embarrassed', 13, 56)," +
                "('jealous', 14, 57)," +
                "('insecure', 14, 58)," +
                "('violated', 15, 59)," +
                "('resentful', 15, 60)," +
                "('enraged', 16, 61)," +
                "('furious', 16, 62)," +
                "('provoked', 17, 63)," +
                "('hostile', 17, 64)," +
                "('infuriated', 18, 65)," +
                "('irritated', 18, 66)," +
                "('withdrawn', 19, 67)," +
                "('suspicious', 19, 68)," +
                "('skeptical', 20, 69)," +
                "('sarcastic', 20, 70)," +
                "('judgemental', 21, 71)," +
                "('loathing', 21, 72)," +
                "('repugnant', 22, 73)," +
                "('revolted', 22, 74)," +
                "('revulsion', 23, 75)," +
                "('detestable', 23, 76)," +
                "('aversion', 24, 77)," +
                "('hesitant', 24, 78)," +
                "('remorseful', 25, 79)," +
                "('ashamed', 25, 80)," +
                "('ignored', 26, 81)," +
                "('victimized', 26, 82)," +
                "('powerless', 27, 83)," +
                "('vulnerable', 27, 84)," +
                "('inferior', 28, 85)," +
                "('empty', 28, 86)," +
                "('abandoned', 29, 87)," +
                "('isolated', 29, 88)," +
                "('indifferent', 30, 89)," +
                "('apathetic', 30, 90)," +
                "('inspired', 31, 91)," +
                "('open', 31, 92)," +
                "('playful', 32, 93)," +
                "('sensitive', 32, 94)," +
                "('hopeful', 33, 95)," +
                "('loving', 33, 96)," +
                "('provocative', 34, 97)," +
                "('courageous', 34, 98)," +
                "('respected', 35, 99)," +
                "('fulfilled', 35, 100)," +
                "('important', 36, 101)," +
                "('confident', 36, 102)," +
                "('amused', 37, 103)," +
                "('inquisitive', 37, 104)," +
                "('liberated', 38, 105)," +
                "('ecstatic', 38, 106)," +
                "('eager', 39, 107)," +
                "('energetic', 39, 108)," +
                "('astonished', 40, 109)," +
                "('awe', 40, 110)," +
                "('disillusioned', 41, 111)," +
                "('perplexed', 41, 112)," +
                "('shocked', 42, 113)," +
                "('dismayed', 42, 114);";


        final String SQL_CREATE_EMOTION_ENTRY_TABLE = "CREATE TABLE " + EmotionEntry.TABLE_NAME
                + " (" +
                EmotionEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EmotionEntry.COLUMN_EMOTION_ID + " INTEGER NOT NULL, " +
                EmotionEntry.COLUMN_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP, " +
                EmotionEntry.COLUMN_COORD_LAT + " REAL NOT NULL, " +
                EmotionEntry.COLUMN_COORD_LON + " REAL NOT NULL, " +
                EmotionEntry.COLUMN_NOTE + " TEXT NOT NULL, " +
                EmotionEntry.COLUMN_IMAGE + " TEXT NOT NULL, " +
                " FOREIGN KEY (" + EmotionEntry.COLUMN_EMOTION_ID + ") REFERENCES " +
                Emotions.TABLE_NAME + " (" + Emotions._ID + ") " +
                "); ";

        sqLiteDatabase.execSQL(SQL_CREATE_EMOTIONS_TABLE);
        sqLiteDatabase.execSQL(SQL_ADD_EMOTIONS_TO_TABLE);
        sqLiteDatabase.execSQL(SQL_CREATE_EMOTION_ENTRY_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + EmotionEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Emotions.TABLE_NAME);
        onCreate(sqLiteDatabase);

    }
}

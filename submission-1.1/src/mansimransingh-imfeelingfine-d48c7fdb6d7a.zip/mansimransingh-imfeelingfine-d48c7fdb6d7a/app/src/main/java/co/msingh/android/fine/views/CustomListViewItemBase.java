package co.msingh.android.fine.views;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.FrameLayout;

import co.msingh.android.fine.utilities.Colors;

/**
 * Created by mani on 09/03/15.
 */
abstract class CustomListViewItemBase extends FrameLayout {
    private Colors.FlatColor color;

    public CustomListViewItemBase(Context context) {
        super(context);
    }

    public CustomListViewItemBase(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CustomListViewItemBase(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public CustomListViewItemBase(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    public interface FlatColorSettings {
        void setFlatColor(Colors.FlatColor color);
    }
}

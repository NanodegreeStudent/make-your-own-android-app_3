package co.msingh.android.fine.views;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;

import co.msingh.android.fine.utilities.Colors;

/**
 * Created by mani on 11/03/15.
 */
public class FlatColorListView extends ListView implements FlatColorBase {
    public FlatColorListView(Context context) {
        super(context);
    }

    public FlatColorListView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public FlatColorListView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    private Colors.FlatColor color[];

    public void initColor() {
        if (color != null) return;
        this.color = Colors.getRandomisedColors();
    }

    public int getColor(int i) {
        initColor();
        return color[getValidIndex(i, color)].getColor();
    }

    public int getValidIndex(int i, Colors.FlatColor[] colors) {
        if (i < 0) {
            i = 0;
        }
        i = i % colors.length;
        return i;
    }

    public Colors.FlatColor getFlatColor(int i) {
        initColor();
        return color[getValidIndex(i, color)];
    }

    public int getAltColor(int i) {
        initColor();
        return color[getValidIndex(i, color)].getAltColor();
    }
}

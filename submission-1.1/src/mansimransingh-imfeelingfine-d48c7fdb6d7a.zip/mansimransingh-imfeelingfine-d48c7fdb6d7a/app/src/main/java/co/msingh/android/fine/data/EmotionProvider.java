package co.msingh.android.fine.data;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;

public class EmotionProvider extends ContentProvider {

    // The URI Matcher used by this content provider.
    private static final UriMatcher sUriMatcher = buildUriMatcher();
    private EmotionDbHelper mOpenHelper;

    private static final int EMOTION = 100;
    private static final int EMOTION_ID = 101;

    private static final int EMOTION_ENTRY = 301;
    private static final int EMOTION_ENTRY_ID = 302;
    private static final int EMOTION_ENTRY_BETWEEN_DATES = 303;
    private static final int EMOTION_ENTRY_WITH_EMOTION_ID = 304;
    private static final int EMOTION_ENTRY_WITH_EMOTION_ID_BETWEEN_DATES = 305;

    private static UriMatcher buildUriMatcher() {
        final UriMatcher matcher = new UriMatcher(UriMatcher.NO_MATCH);
        final String authority = EmotionContract.CONTENT_AUTHORITY;

        //get all emotions
        matcher.addURI(
                authority,
                EmotionContract.PATH_EMOTION,
                EMOTION);

        //get a single emotion
        matcher.addURI(
                authority,
                EmotionContract.PATH_EMOTION + "/#",
                EMOTION_ID);

        //gets emotion entries based on an emotion id
        matcher.addURI(
                authority,
                EmotionContract.PATH_EMOTION_ENTRY + "/emotion/#",
                EMOTION_ENTRY_WITH_EMOTION_ID);

        //a single emotion entry
        matcher.addURI(
                authority,
                EmotionContract.PATH_EMOTION_ENTRY,
                EMOTION_ENTRY);

        //gets all emotion entries between two dates
        matcher.addURI(
                authority,
                EmotionContract.PATH_EMOTION_ENTRY + "/*/*",
                EMOTION_ENTRY_BETWEEN_DATES);

        //gets a single emotion entry with emotion entry id
        matcher.addURI(
                authority,
                EmotionContract.PATH_EMOTION_ENTRY + "/*",
                EMOTION_ENTRY_ID);

        //get emotion entries based on emotion id between 2 dates
        matcher.addURI(
                authority,
                EmotionContract.PATH_EMOTION_ENTRY + "/emotion/#/*/*",
                EMOTION_ENTRY_WITH_EMOTION_ID_BETWEEN_DATES);

        //URI for recursive get on emotion entries - for counts, etc

        return matcher;
    }

    private static final SQLiteQueryBuilder sEmotionEntryByEmotionIdSettingQueryBuilder;

    static {
        sEmotionEntryByEmotionIdSettingQueryBuilder = new SQLiteQueryBuilder();
        sEmotionEntryByEmotionIdSettingQueryBuilder.setTables(
                EmotionContract.EmotionEntry.TABLE_NAME + " INNER JOIN " +
                        EmotionContract.Emotions.TABLE_NAME +
                        " ON " + EmotionContract.EmotionEntry.TABLE_NAME +
                        "." + EmotionContract.EmotionEntry.COLUMN_EMOTION_ID +
                        " = " + EmotionContract.Emotions.TABLE_NAME +
                        "." + EmotionContract.Emotions._ID
        );
    }


//    private static final String sLocationSettingSelection =
//            WeatherContract.LocationEntry.TABLE_NAME+
//                    "." + WeatherContract.LocationEntry.COLUMN_LOCATION_SETTING + " = ? ";
//    private static final String sLocationSettingWithStartDateSelection =
//            WeatherContract.LocationEntry.TABLE_NAME+
//                    "." + WeatherContract.LocationEntry.COLUMN_LOCATION_SETTING + " = ? AND " +
//                    WeatherContract.WeatherEntry.COLUMN_DATETEXT + " >= ? ";
//
//    private static final String sLocationSettingAndDaySelection =
//            WeatherContract.LocationEntry.TABLE_NAME +
//                    "." + WeatherContract.LocationEntry.COLUMN_LOCATION_SETTING + " = ? AND " +
//                    WeatherContract.WeatherEntry.COLUMN_DATETEXT + " = ? ";
//
//    private Cursor getWeatherByLocationSetting(Uri uri, String[] projection, String sortOrder) {
//        String locationSetting = WeatherContract.WeatherEntry.getLocationSettingFromUri(uri);
//        String startDate = WeatherContract.WeatherEntry.getStartDateFromUri(uri);
//
//        String[] selectionArgs;
//        String selection;
//
//        if (startDate == null) {
//            selection = sLocationSettingSelection;
//            selectionArgs = new String[]{locationSetting};
//        } else {
//            selectionArgs = new String[]{locationSetting, startDate};
//            selection = sLocationSettingWithStartDateSelection;
//        }
//
//        return sWeatherByLocationSettingQueryBuilder.query(mOpenHelper.getReadableDatabase(),
//                projection,
//                selection,
//                selectionArgs,
//                null,
//                null,
//                sortOrder
//        );
//    }
//
//    private Cursor getWeatherByLocationSettingAndDate(
//            Uri uri, String[] projection, String sortOrder) {
//        String locationSetting = WeatherContract.WeatherEntry.getLocationSettingFromUri(uri);
//        Long date = WeatherContract.WeatherEntry.getDateFromUri(uri);
//
//        return sWeatherByLocationSettingQueryBuilder.query(mOpenHelper.getReadableDatabase(),
//                projection,
//                sLocationSettingAndDaySelection,
//                new String[]{locationSetting, Long.toString(date)},
//                null,
//                null,
//                sortOrder
//        );
//    }

    @Override
    public boolean onCreate() {
        mOpenHelper = new EmotionDbHelper(getContext());
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {
        Cursor retCursor;
        switch (sUriMatcher.match(uri)) {
            case EMOTION:
                retCursor = mOpenHelper.getReadableDatabase().query(
                        EmotionContract.Emotions.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder
                );
                break;
            case EMOTION_ID:
                retCursor = mOpenHelper.getReadableDatabase().query(
                        EmotionContract.Emotions.TABLE_NAME,
                        projection,
                        EmotionContract.Emotions._ID + " = '" + ContentUris.parseId(uri) + "'",
                        null,
                        null,
                        null,
                        sortOrder
                );
                break;
            case EMOTION_ENTRY_WITH_EMOTION_ID:
                //gets emotion entries based on an emotion id
//                matcher.addURI(
//                        authority,
//                        EmotionContract.PATH_EMOTION_ENTRY+"/emotion/#",
//                        EMOTION_ENTRY_WITH_EMOTION_ID);
                throw new UnsupportedOperationException("Unknown uri: " + uri);
//                break;
            case EMOTION_ENTRY:
//                retCursor = mOpenHelper.getReadableDatabase().query(
//                        EmotionContract.EmotionEntry.TABLE_NAME,
//                            projection,
//                            selection,
//                            selectionArgs,
//                            null,
//                            null,
//                            sortOrder
//                );
                retCursor = sEmotionEntryByEmotionIdSettingQueryBuilder.query(mOpenHelper.getReadableDatabase(),
                        projection,
                        null,
                        null,
                        null,
                        null,
                        sortOrder
                );
                break;
            case EMOTION_ENTRY_ID:
                retCursor = sEmotionEntryByEmotionIdSettingQueryBuilder.query(mOpenHelper.getReadableDatabase(),
                        projection,
                        EmotionContract.EmotionEntry.TABLE_NAME + "." + EmotionContract.EmotionEntry._ID + " = '" + ContentUris.parseId(uri) + "'",
                        null,
                        null,
                        null,
                        sortOrder
                );


                break;
            case EMOTION_ENTRY_BETWEEN_DATES:
                //gets all emotion entries between two dates
//            matcher.addURI(
//                    authority,
//                    EmotionContract.PATH_EMOTION_ENTRY+"/*/*",
//                    EMOTION_ENTRY_BETWEEN_DATES);
                throw new UnsupportedOperationException("Unknown uri: " + uri);
//                break;
            case EMOTION_ENTRY_WITH_EMOTION_ID_BETWEEN_DATES:

//            //get emotion entries based on emotion id between 2 dates
//            matcher.addURI(
//                    authority,
//                    EmotionContract.PATH_EMOTION_ENTRY+"/emotion/#/*/*",
//                    EMOTION_ENTRY_WITH_EMOTION_ID_BETWEEN_DATES);
                throw new UnsupportedOperationException("Unknown uri: " + uri);
//                break;


            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
        retCursor.setNotificationUri(getContext().getContentResolver(), uri);
        return retCursor;
    }

    @Override
    public String getType(Uri uri) {

        // Use the Uri Matcher to determine what kind of URI this is.
        final int match = sUriMatcher.match(uri);

        switch (match) {
            case EMOTION:
                return EmotionContract.Emotions.CONTENT_TYPE;
            case EMOTION_ID:
                return EmotionContract.Emotions.CONTENT_ITEM_TYPE;
            case EMOTION_ENTRY_WITH_EMOTION_ID:
                return EmotionContract.EmotionEntry.CONTENT_TYPE;
            case EMOTION_ENTRY:
                return EmotionContract.EmotionEntry.CONTENT_ITEM_TYPE;
            case EMOTION_ENTRY_BETWEEN_DATES:
                return EmotionContract.EmotionEntry.CONTENT_TYPE;
            case EMOTION_ENTRY_ID:
                return EmotionContract.EmotionEntry.CONTENT_ITEM_TYPE;
            case EMOTION_ENTRY_WITH_EMOTION_ID_BETWEEN_DATES:
                return EmotionContract.EmotionEntry.CONTENT_TYPE;
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        final SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        final int match = sUriMatcher.match(uri);
        Uri returnUri;

        switch (match) {
            case EMOTION_ENTRY: {
                long _id = db.insert(EmotionContract.EmotionEntry.TABLE_NAME, null, values);
                if (_id > 0)
                    returnUri = EmotionContract.EmotionEntry.buildEmotionEntryURI(_id);
                else
                    throw new android.database.SQLException("Failed to insert row into " + uri);
                break;
            }
            case EMOTION:
                throw new UnsupportedOperationException("Cannot enter emotion");

            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return returnUri;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        final SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        final int match = sUriMatcher.match(uri);
        int rowsDeleted;
        switch (match) {
            case EMOTION_ENTRY_ID:
                rowsDeleted = db.delete(
                        EmotionContract.EmotionEntry.TABLE_NAME,
                        EmotionContract.EmotionEntry.TABLE_NAME + "." + EmotionContract.EmotionEntry._ID + " = '" + ContentUris.parseId(uri) + "'",
                        null
                );
                break;
            case EMOTION:
                throw new UnsupportedOperationException("Cannot delete emotion");
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
        // Because a null deletes all rows
        if (selection == null || rowsDeleted != 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return rowsDeleted;
    }

    @Override
    public int update(
            Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        final SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        final int match = sUriMatcher.match(uri);
        int rowsDeleted;
        switch (match) {
            case EMOTION_ENTRY:
                rowsDeleted = db.update(
                        EmotionContract.EmotionEntry.TABLE_NAME, values, selection, selectionArgs);
                break;
            case EMOTION:
                throw new UnsupportedOperationException("Cannot update emotion");
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
        // Because a null deletes all rows
        if (selection == null || rowsDeleted != 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return rowsDeleted;

    }

    @Override
    public int bulkInsert(Uri uri, ContentValues[] values) {
        final SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        final int match = sUriMatcher.match(uri);
        switch (match) {
            case EMOTION_ENTRY:
                db.beginTransaction();
                int returnCount = 0;
                try {
                    for (ContentValues value : values) {
                        long _id = db.insert(EmotionContract.EmotionEntry.TABLE_NAME, null, value);
                        if (_id != -1) {
                            returnCount++;
                        }
                    }
                    db.setTransactionSuccessful();
                } finally {
                    db.endTransaction();
                }
                getContext().getContentResolver().notifyChange(uri, null);
                return returnCount;
            default:
                return super.bulkInsert(uri, values);
        }
    }
}

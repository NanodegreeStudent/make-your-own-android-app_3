package co.msingh.android.fine;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.support.v4.app.NotificationCompat;

/**
 * Created by mani on 13/03/15.
 */
public class AlarmReceiver extends BroadcastReceiver {

    public static final int REMINDER_NOTIFICATION_ID = 3095;

    @Override
    public void onReceive(Context context, Intent intent) {
        NotificationCompat.Builder n = new NotificationCompat.Builder(context)
                .setContentTitle(context.getResources().getString(R.string.notification_title))
                .setContentText(context.getResources().getString(R.string.notification_text))
                .setSmallIcon(R.mipmap.ic_launcher)
                .setLargeIcon(new BitmapFactory().decodeResource(
                        context.getResources(),
                        R.drawable.logo
                ))
                .setAutoCancel(true);


        Intent i = new Intent(context, ActivityNewEntry.class);

        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, i, 0);

        n.setContentIntent(pendingIntent);

        NotificationManager mNotificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        mNotificationManager.notify(REMINDER_NOTIFICATION_ID, n.build());
    }
}

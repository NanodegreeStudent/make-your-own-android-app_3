package co.msingh.android.fine.utilities;

import android.util.Log;

import java.util.Random;

import co.msingh.android.fine.R;

public class Colors {
    public static final FlatColor[] FANCY_COLORS = new FlatColor[]{
            new FlatColor(R.color.flat_red, R.color.flat_red_alt),
            new FlatColor(R.color.flat_orange, R.color.flat_orange_alt),
            new FlatColor(R.color.flat_yellow, R.color.flat_yellow_alt),
            new FlatColor(R.color.flat_magenta, R.color.flat_magenta_alt),
            new FlatColor(R.color.flat_sky_blue, R.color.flat_sky_blue_alt),
            new FlatColor(R.color.flat_green, R.color.flat_green_alt),
            new FlatColor(R.color.flat_watermelon, R.color.flat_watermelon_alt),
            new FlatColor(R.color.flat_lime, R.color.flat_lime_alt),
            new FlatColor(R.color.flat_pink, R.color.flat_pink_alt),
    };

    public static final FlatColor[] BASE_COLORS = new FlatColor[]{
            new FlatColor(R.color.flat_teal, R.color.flat_teal_alt),
            new FlatColor(R.color.flat_navy_blue, R.color.flat_navy_blue_alt),
            new FlatColor(R.color.flat_black, R.color.flat_black_alt),
            new FlatColor(R.color.flat_white, R.color.flat_white_alt),
            new FlatColor(R.color.flat_gray, R.color.flat_gray_alt)
    };

    public static FlatColor[] getRandomisedColors() {
        FlatColor[] ret = FANCY_COLORS;
        Random rnd = new Random();
        for (int i = ret.length - 1; i > 0; i--) {
            int index = rnd.nextInt(i + 1);
            // Simple swap
            FlatColor a = ret[index];
            ret[index] = ret[i];
            ret[i] = a;
        }
        Log.d(Generic.LOG_TAG, " INITIALISING COLOURS");
        return ret;
    }

    public static class FlatColor {
        private int color;
        private int altColor;

        public FlatColor(int color, int altColor) {
            this.color = color;
            this.altColor = altColor;
        }

        public int getColor() {
            return color;
        }

        public int getAltColor() {
            return altColor;
        }
    }
}

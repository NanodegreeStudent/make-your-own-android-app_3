package co.msingh.android.fine.data;


import android.content.ContentUris;
import android.net.Uri;
import android.provider.BaseColumns;

public class EmotionContract {

    public static final String CONTENT_AUTHORITY = "co.msingh.android.imfeelingfine";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static final String PATH_EMOTION_ENTRY = "emotion_entry";

    public static final String PATH_EMOTION = "emotions";

    public static final class EmotionEntry implements BaseColumns {

        public static final String TABLE_NAME = "emotion_entry";

        public static final String COLUMN_EMOTION_ID = "emotion_id";

        public static final String COLUMN_CREATED_AT = "created_at";

        public static final String COLUMN_COORD_LAT = "coord_lat";

        public static final String COLUMN_COORD_LON = "coord_lon";

        public static final String COLUMN_NOTE = "note";

        public static final String COLUMN_IMAGE = "image";

        public static final Uri CONTENT_URI =
                BASE_CONTENT_URI.buildUpon().appendPath(PATH_EMOTION_ENTRY).build();

        public static final String CONTENT_TYPE =
                "vnd.android.cursor.dir/" + CONTENT_AUTHORITY + "/" + PATH_EMOTION_ENTRY;
        public static final String CONTENT_ITEM_TYPE =
                "vnd.android.cursor.item/" + CONTENT_AUTHORITY + "/" + PATH_EMOTION_ENTRY;


        public static Uri buildEmotionEntryURI(long id) {
            return ContentUris.withAppendedId(CONTENT_URI, id);
        }


    }

    public static final class Emotions implements BaseColumns {
        public static final String TABLE_NAME = "emotions";

        public static final String COLUMN_EMOTION_NAME = "emotion_name";

        public static final String COLUMN_EMOTION_PARENT_ID = "parent_id";

        public static final Uri CONTENT_URI =
                BASE_CONTENT_URI.buildUpon().appendPath(PATH_EMOTION).build();

        public static final String CONTENT_TYPE =
                "vnd.android.cursor.dir/" + CONTENT_AUTHORITY + "/" + PATH_EMOTION;
        public static final String CONTENT_ITEM_TYPE =
                "vnd.android.cursor.item/" + CONTENT_AUTHORITY + "/" + PATH_EMOTION;


        public static Uri buildEmotionURI(long id) {
            return ContentUris.withAppendedId(CONTENT_URI, id);
        }
    }
}

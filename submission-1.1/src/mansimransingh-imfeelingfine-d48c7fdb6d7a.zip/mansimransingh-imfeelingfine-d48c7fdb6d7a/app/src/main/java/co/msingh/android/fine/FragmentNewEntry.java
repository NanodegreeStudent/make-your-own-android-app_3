package co.msingh.android.fine;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import co.msingh.android.fine.data.EmotionContract;
import co.msingh.android.fine.swipelistview.BaseSwipeListViewListener;
import co.msingh.android.fine.utilities.Generic;
import co.msingh.android.fine.views.FlatColorListWithSwipeView;

public class FragmentNewEntry extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {
    //this is for getting emotions to simply "check in" to the db
    //we will do another fragment for seeing history
    private static final String[] EMOTIONS_COLUMNS = {
            EmotionContract.Emotions._ID,
            EmotionContract.Emotions.COLUMN_EMOTION_NAME,
            EmotionContract.Emotions.COLUMN_EMOTION_PARENT_ID
    };

    static final int COLUMN_EMOTION_ID = 0;
    static final int COLUMN_EMOTION_NAME = 1;
    static final int COLUMN_EMOTION_PARENT_ID = 2;

    //loader id of emotion loader - will be diff for emotion entry loader (or stats loader?)
    private static final int EMOTION_LOADER = 0;
    private AdapterNewEntry mAdapterNewEntry;
    private FlatColorListWithSwipeView mListView;
    private static final String SELECTED_KEY = "selected";
    private int mPosition = ListView.INVALID_POSITION;
    private int mCurrentParentId;
    private int mCurrentLevel;
    private BaseSwipeListViewListener baseSwipeListViewListener;

//    private Colors.FlatColor highlightColor;
//    private Colors.FlatColor highlightColor2;
//    private ImageView mHighlight;
//    private ImageView mHighlight2;

    private boolean isSwiping;

//    private boolean isSwipingLeft;

    private static final String ARG_PARENT_ID = "parent_id";
    private static final String ARG_CURRENT_LEVEL = "current_level";

    private static boolean isDisabled = false;

    /**
     * Returns a new instance of this fragment for the given section
     * number.
     */
    public static FragmentNewEntry newInstance(int parentId, int level) {
        FragmentNewEntry fragment = new FragmentNewEntry();
        Bundle args = new Bundle();
        args.putInt(ARG_PARENT_ID, parentId);
        args.putInt(ARG_CURRENT_LEVEL, level);
        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Uri emotionsUri = EmotionContract.Emotions.CONTENT_URI;

        return new CursorLoader(getActivity(),
                emotionsUri,
                EMOTIONS_COLUMNS,
                EmotionContract.Emotions.COLUMN_EMOTION_PARENT_ID + " = " + mCurrentParentId,
                null,
                null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        mAdapterNewEntry.swapCursor(data);

        if (data.getCount() > 0) {
            mAdapterNewEntry.setHeight(Generic.getAvailableHeight(getActivity()) / data.getCount());
        }


        if (mPosition != ListView.INVALID_POSITION) {
            mListView.smoothScrollToPosition(mPosition);
        }
    }

//    public void setHighlightColor(Colors.FlatColor c){
//        highlightColor = c;
//    }
//
//    public void setHighlightColor(Colors.FlatColor c, Colors.FlatColor c2){
//        highlightColor = c;
//        highlightColor2 = c2;
//    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        mAdapterNewEntry.swapCursor(null);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        isSwiping = false;
        initBaseSwipeListViewListener();

        Bundle args = getArguments();
        if (args != null) {
            mCurrentParentId = args.getInt(ARG_PARENT_ID, 0);
            mCurrentLevel = args.getInt(ARG_CURRENT_LEVEL, 0);
        } else {
            mCurrentParentId = 0;
            mCurrentLevel = 0;
        }

        mAdapterNewEntry = new AdapterNewEntry(getActivity(), null, 0);

        View rootView = inflater.inflate(R.layout.fragment_new_entry, container, false);

        mListView = (FlatColorListWithSwipeView) rootView.findViewById(R.id.listview_emotions);
        mListView.setAdapter(mAdapterNewEntry);

        mListView.setSwipeListViewListener(baseSwipeListViewListener);

        if (savedInstanceState != null && savedInstanceState.containsKey(SELECTED_KEY)) {
            mPosition = savedInstanceState.getInt(SELECTED_KEY);
        }

//        mHighlight = (ImageView)rootView.findViewById(R.id.highlight_color_1);
//        mHighlight2 = (ImageView)rootView.findViewById(R.id.highlight_color_2);
//
//        if(mCurrentLevel > 0){
//            mHighlight.setBackgroundColor(getResources().getColor(highlightColor.getColor()));
//            mHighlight.setVisibility(View.VISIBLE);
//
//            if(mCurrentLevel == 2 && highlightColor2 != null){
//                mHighlight2.setBackgroundColor(getResources().getColor(highlightColor2.getColor()));
//                mHighlight2.setVisibility(View.VISIBLE);
//            }
//        }
        return rootView;
    }

    public interface Callback {
        public void onItemSelected(View view, int level, float deltaX, boolean isSwiping);

        public void onClickBackView(int position, FlatColorListWithSwipeView listView);

        public void onClickFrontView(int position, FlatColorListWithSwipeView listView);

        public void onOpened(int position, FlatColorListWithSwipeView listView);
    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        getLoaderManager().initLoader(EMOTION_LOADER, null, this);
        super.onActivityCreated(savedInstanceState);
    }

    private void initBaseSwipeListViewListener() {
        this.baseSwipeListViewListener = new BaseSwipeListViewListener() {
            @Override
            public void onOpened(int position, boolean toRight) {
                ((Callback) getActivity())
                        .onOpened(position, mListView);


            }

            @Override
            public void onClickFrontView(int position) {
                Log.d(Generic.LOG_TAG, String.format("onClickFrontView %d", position));

//                mListView.openAnimate(position); //when you touch front view it will open
                //do nothing on click? or on click we should show the definition

                ((Callback) getActivity()).onClickFrontView(position, mListView);
            }

            @Override
            public void onClickBackView(int position) {
                Log.d(Generic.LOG_TAG, String.format("onClickBackView %d", position));

//                mListView.closeAnimate(position);//when you touch back view it will close
                //this is where we can undo the save
                ((Callback) getActivity())
                        .onClickBackView(position, mListView);
            }

            @Override
            public void onSwipeNoAction(int position, boolean right, float deltaX) {
                if (deltaX > 100 && isSwiping == false) {

                    isSwiping = true;

                    ((Callback) getActivity()).
                            onItemSelected(mListView.getChildAt(position),
                                    mCurrentLevel + 1, deltaX, !isSwiping);

                }
            }
        };
    }
}

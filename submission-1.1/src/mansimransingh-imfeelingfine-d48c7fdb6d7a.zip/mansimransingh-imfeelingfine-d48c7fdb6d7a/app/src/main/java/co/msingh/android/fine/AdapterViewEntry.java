package co.msingh.android.fine;

import android.content.Context;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import co.msingh.android.fine.utilities.Generic;
import co.msingh.android.fine.views.EntryListViewItem;
import co.msingh.android.fine.views.FlatColorListView;

/**
 * Created by mani on 11/03/15.
 */
public class AdapterViewEntry extends CursorAdapter {
    public AdapterViewEntry(Context context, Cursor c, int flags) {
        super(context, c, flags);
        height = 0;
    }

    private int height;

    public void setHeight(int h) {
        this.height = h;
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(R.layout.entry_list_item, parent, false);

//        view.setLayoutParams(new LinearLayout.LayoutParams(view.getWidth(), height));
        view.setMinimumHeight(height);

        int position = cursor.getPosition();
        FlatColorListView flatColorListView = (FlatColorListView) parent;

        ((EntryListViewItem) view).setFlatColor(flatColorListView.getFlatColor(position));
//        view.setBackgroundColor(context.getResources().getColor(flatColorListView.getColor(position)));

        ColorDrawable color = new ColorDrawable();
        ColorDrawable altColor = new ColorDrawable();

        color.setColor(context.getResources().getColor(flatColorListView.getColor(position)));
        altColor.setColor(context.getResources().getColor(flatColorListView.getAltColor(position)));

//        StateListDrawable stateListDrawable = new StateListDrawable();
//        stateListDrawable.addState(new int[]{android.R.attr.state_pressed}, altColor);
//        stateListDrawable.addState(StateSet.WILD_CARD, color);
//        stateListDrawable.addState(new int[]{android.R.attr.state_pressed}, altColor);

//
//        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN){
//           // view.setBackground(stateListDrawable);
//        } else {
//           // view.setBackgroundDrawable(stateListDrawable);
//        }

        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        int id = cursor.getInt(FragmentListEntry.COL_ENTRY_ID);
        String name = cursor.getString(FragmentListEntry.COL_EMOTION_NAME);
        String date = cursor.getString(FragmentListEntry.COL_CREATED_AT);

        ((TextView) view.findViewById(R.id.textView_entry_list_emotion_name)).setText(name);
        ((TextView) view.findViewById(R.id.textView_entry_list_date))
                .setText(Generic.formatDate(date));

        ((EntryListViewItem) view).setEntryId(id);
    }
}

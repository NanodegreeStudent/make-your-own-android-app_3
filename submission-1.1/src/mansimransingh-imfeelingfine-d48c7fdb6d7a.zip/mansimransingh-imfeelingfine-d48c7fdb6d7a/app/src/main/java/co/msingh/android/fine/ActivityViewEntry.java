package co.msingh.android.fine;


import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

public class ActivityViewEntry extends ActionBarActivity{

    public static final String URI = "uri";
    public static final String ALT_COLOR = "flat_color";
    private final String FRAGMENT_TAG = "view_entry_fragment";
    private boolean isSaved;
    private FragmentViewEntry fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_entry);

        if (savedInstanceState == null) {
            Bundle arguments = new Bundle();
            arguments.putString(
                    FragmentViewEntry.ENTRY_URI,
                    getIntent().getStringExtra(ActivityEditEntry.URI)
            );
            int color = getIntent().getIntExtra(ActivityEditEntry.ALT_COLOR, 0);
            arguments.putInt(FragmentViewEntry.FLAT_ALT_COLOR,color
            );

            fragment = new FragmentViewEntry();
            fragment.setArguments(arguments);

            getSupportFragmentManager().beginTransaction()
                    .add(R.id.edit_entry_container, fragment, FRAGMENT_TAG)
                    .commit();
        }
        isSaved = false;
    }


    @Override
    public void onBackPressed() {
        FragmentViewEntry fg = (FragmentViewEntry) getSupportFragmentManager().findFragmentByTag(FRAGMENT_TAG);

        if(fg == null || fg.backPressed()) {
            super.onBackPressed();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
    }

}

package co.msingh.android.fine;


import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.Locale;

import co.msingh.android.fine.data.EmotionContract;
import co.msingh.android.fine.utilities.Generic;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentViewEntry extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {
    static final String ENTRY_URI = "URI";
    private static final int ENTRY_LOADER = 0;
    public static final String FLAT_ALT_COLOR = "ALT_COLOR";
    private Uri mUri;
    private boolean havePhoto;
    static final int REQUEST_IMAGE_GET = 1;
    private final int THUMBNAIL_SIZE = 500;
    private Uri mPhotoUri;

    private static final String[] ENTRY_COLUMNS = {
            EmotionContract.EmotionEntry.TABLE_NAME + "." + EmotionContract.EmotionEntry._ID,
            EmotionContract.EmotionEntry.COLUMN_EMOTION_ID,
            EmotionContract.EmotionEntry.COLUMN_CREATED_AT,
            EmotionContract.EmotionEntry.COLUMN_COORD_LAT,
            EmotionContract.EmotionEntry.COLUMN_COORD_LON,
            EmotionContract.EmotionEntry.COLUMN_NOTE,
            EmotionContract.EmotionEntry.COLUMN_IMAGE,
            EmotionContract.Emotions.TABLE_NAME + "." + EmotionContract.Emotions.COLUMN_EMOTION_NAME,
    };

    private static final int COL_ENTRY_ID = 0;
    private static final int COL_EMOTION_ID = 1;
    private static final int COL_CREATED_AT = 2;
    private static final int COL_COORD_LAT = 3;
    private static final int COL_COORD_LON = 4;
    private static final int COL_NOTE = 5;
    private static final int COL_IMAGE = 6;
    private static final int COL_EMOTION_NAME = 7;

    private TextView mDateTextView;
    private TextView mTitleTextView;
    private TextView mTextNote;
    private int entryId;
    private ImageView mImageView, mFullscreenImageView, mMapTileView;
    private FrameLayout mFullScreenFrame;
    private int color;
    private String lat;
    private String lon;

    private boolean allowAddLocation;

    public FragmentViewEntry() {
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        getLoaderManager().initLoader(ENTRY_LOADER, null, this);
        super.onActivityCreated(savedInstanceState);

        allowAddLocation = false;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        color = -1;
        Bundle arguments = getArguments();
        if (arguments != null) {
            mUri = Uri.parse(arguments.getString(FragmentEditEntry.ENTRY_URI));
            color = arguments.getInt(FragmentEditEntry.FLAT_ALT_COLOR);
        }

        final View rootView = inflater.inflate(R.layout.fragment_view_entry, container, false);

        if (color != -1) {
            //this will be the colour the list item was displayed in ;)
            rootView.setBackgroundColor(getResources().getColor(color));
            Log.d(Generic.LOG_TAG, "SETTING COLOUR TO ID: "+color);
        }

        mTitleTextView = (TextView) rootView.findViewById(R.id.textView_add_note_title);
        mDateTextView = (TextView) rootView.findViewById(R.id.textView_add_note_date);
        mTextNote = (TextView) rootView.findViewById(R.id.textView_note_text);
        mImageView = (ImageView) rootView.findViewById(R.id.imageView_edit_entry_image);
        mFullscreenImageView = (ImageView) rootView.findViewById(R.id.imageView_fullscreen_image);
        mFullScreenFrame = (FrameLayout) rootView.findViewById(R.id.fullscreen_frame);
        mMapTileView = (ImageView) rootView.findViewById(R.id.imageView_edit_entry_map);

        havePhoto = false;

        mImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFullScreenFrame.setVisibility(View.VISIBLE);
            }
        });

        mFullscreenImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rootView.findViewById(R.id.fullscreen_frame).setVisibility(View.GONE);
            }
        });

        mMapTileView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMap();
            }
        });

        Log.d(Generic.LOG_TAG, "HAVE URI AS: " + mUri);
        return rootView;
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        if (mUri != null) {
            return new CursorLoader(
                    getActivity(),
                    mUri,
                    ENTRY_COLUMNS,
                    null,
                    null,
                    null
            );
        }
        return null;
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (data != null && data.moveToFirst()) {
            int emotionId = data.getInt(COL_EMOTION_ID);

            entryId = data.getInt(COL_ENTRY_ID);
            String createdAt = data.getString(COL_CREATED_AT);

            String emotionName = data.getString(COL_EMOTION_NAME);
            String note = data.getString(COL_NOTE);
            String image = data.getString(COL_IMAGE);

            lat = data.getString(COL_COORD_LAT);
            lon = data.getString(COL_COORD_LON);

            if(!lat.matches("")  && !lon.matches("")){
                Log.d(Generic.LOG_TAG, "GOT LOCATION AS: "+lat+" "+lon);
                String url = "http://maps.google.com/maps/api/staticmap?center="+lat+","+lon+"&zoom=14&size=500x400&sensor-false&markers=color:red%7C"+lat+","+lon;

                Picasso.with(getActivity()).load(url).into(mMapTileView);

                mMapTileView.setVisibility(View.VISIBLE);
            } else {
                allowAddLocation = true;
            }

            if(image != ""){

                try {
                    Uri fullPhotoUri = Uri.parse(image);
                    Log.d(Generic.LOG_TAG, "PARSED A URI: "+mPhotoUri);

                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), fullPhotoUri);
                    if (bitmap == null) throw new Exception();

                    mPhotoUri = fullPhotoUri;
                    gotPhoto(bitmap);
                } catch (Exception e){

                }

            }
            mTitleTextView.setText(emotionName);
            mDateTextView.setText(Generic.formatDate(createdAt));
            mTextNote.setText(note);
        }
    }

    // return true if everything is cool and we should press back
    public boolean backPressed(){
        if(mFullScreenFrame.getVisibility() == View.VISIBLE){
            mFullScreenFrame.setVisibility(View.GONE);
            return false;
        }
        return true;
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }


    public void selectImage() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivityForResult(intent, REQUEST_IMAGE_GET);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_GET && resultCode == getActivity().RESULT_OK) {
//            Bitmap thumbnail = data.getParcelable("data");
            Uri fullPhotoUri = data.getData();
            // Do work with photo saved at fullPhotoUri
            try {
//                Bitmap bitmap = getThumbnail(fullPhotoUri);
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), fullPhotoUri);
                if (bitmap == null) throw new Exception();

                mPhotoUri = fullPhotoUri;
                gotPhoto(bitmap);
            } catch (Exception e) {
                havePhoto = false;
                Toast.makeText(getActivity(), getResources().getString(R.string.failed_image_load), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void gotPhoto(Bitmap bitmap) {
        havePhoto = true;
        mImageView.setVisibility(View.VISIBLE);

        setImage(bitmap);


    }

    private void noPhoto() {
        havePhoto = false;
        mImageView.setVisibility(View.GONE);
    }

    public void setImage(Bitmap image) {
        mImageView.setImageBitmap(image);
        mFullscreenImageView.setImageBitmap(image);
    }

    public int getColor(){
        return color;
    }

    public int getEntryId(){
        return entryId;
    }

    public void removeFragment(){
        getActivity().getSupportFragmentManager().beginTransaction().remove(this).commit();
    }

    private void showMap(){
        Uri geoLocation = Uri.parse(String.format(Locale.ENGLISH, "geo:%s,%s?q=%s,%s", lat, lon, lat, lon));
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(geoLocation);
        if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
            getActivity().startActivity(intent);
        }
    }
}

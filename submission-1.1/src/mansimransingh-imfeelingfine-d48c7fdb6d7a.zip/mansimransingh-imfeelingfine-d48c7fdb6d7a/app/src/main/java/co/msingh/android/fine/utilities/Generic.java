package co.msingh.android.fine.utilities;

import android.content.Context;
import android.util.DisplayMetrics;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by mani on 09/03/15.
 */
public class Generic {
    public static final String LOG_TAG = ">> imfeelingfine";

    //TODO do nice dates like "Today at 5:30am", "Yesterday at 6:40pm"
    // 3rd March, 2015 at
    public static String formatDate(String d) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        try {
            Date date = formatter.parse(d);
            formatter.applyPattern("d");
            String start = ordinal(Integer.parseInt(formatter.format(date)));
            formatter.applyPattern("MMM, ''yy 'at' h:ma");
            return start + formatter.format(date);

        } catch (ParseException e) {
            e.printStackTrace();
            return d;
        }
    }

    /**
     * from http://stackoverflow.com/questions/6810336/is-there-a-library-or-utility-in-java-to-convert-an-integer-to-its-ordinal
     */
    public static String ordinal(int i) {
        String[] sufixes = new String[]{"th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th"};
        switch (i % 100) {
            case 11:
            case 12:
            case 13:
                return i + "th ";
            default:
                return i + sufixes[i % 10] + " ";

        }
    }

    public static int getAvailableHeight(Context ctx) {
        DisplayMetrics displayMetrics = ctx.getResources().getDisplayMetrics();
        return displayMetrics.heightPixels;
    }

    public static int getAvailableWidth(Context ctx) {
        DisplayMetrics displayMetrics = ctx.getResources().getDisplayMetrics();
        return displayMetrics.widthPixels;
    }

    public static String getDateTime(){
        Calendar c = Calendar.getInstance();

        return c.get(Calendar.YEAR)+"-"+
                String.format("%02d",c.get(Calendar.MONTH)+1)+"-"+ //for some weird reason, months are 0 indexed? WTF
                String.format("%02d",c.get(Calendar.DAY_OF_MONTH))+" "+
                String.format("%02d",c.get(Calendar.HOUR_OF_DAY))+":"+
                String.format("%02d",c.get(Calendar.MINUTE))+":"+
                String.format("%02d",c.get(Calendar.SECOND));
    }

    public static float pixelsToSp(Context context, float px) {
        float scaledDensity = context.getResources().getDisplayMetrics().scaledDensity;
        return px/scaledDensity;
    }
}

package co.msingh.android.fine;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;

import co.msingh.android.fine.data.EmotionContract;
import co.msingh.android.fine.utilities.Animations;
import co.msingh.android.fine.utilities.Colors;
import co.msingh.android.fine.utilities.Generic;
import co.msingh.android.fine.views.EmotionListViewItem;
import co.msingh.android.fine.views.FlatColorListWithSwipeView;


public class ActivityNewEntry extends ActionBarActivity implements
        FragmentNewEntry.Callback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener
{
    //    private int mSelectedEmotion;
//    private FragmentNewEntry  mSecondLevelFragment, mThirdLevelFragment;
//    private int mCurrentLevel;
//    private final String FRAGMENT_LEVEL_PREFIX = "fragment_level_";
    private FragmentNewEntry mBaseFragment;
    private Colors.FlatColor mBaseColor;
    private ImageView mImageView;
    private int mCurrentLevel, mCurrentEmotion;
    private final String FRAGMENT_LEVEL_PREFIX = "fragment_leve_";

    protected GoogleApiClient mGoogleApiClient;
    protected Location mLastLocation;

    private int openedPosition;
    private FlatColorListWithSwipeView openedFlastColorListWithSwipeView;
    private  ContentValues values;

    private boolean haveSomethingToSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_entry);
        if (savedInstanceState == null) {
            mBaseFragment = new FragmentNewEntry();
            mCurrentLevel = 0;
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.base_emotion_frame, mBaseFragment)
                    //.addToBackStack(FRAGMENT_LEVEL_PREFIX+mCurrentLevel)

                    .commit();

            mCurrentEmotion = 0;
        }

        buildGoogleApiClient();

        haveSomethingToSave = false;
    }

    protected synchronized void buildGoogleApiClient(){
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
    }

    @Override
    protected void onStart(){
        super.onStart();

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        Boolean saveLocation = prefs.getBoolean(getResources().getString(R.string.pref_location_key), true);
        if(saveLocation){
            mGoogleApiClient.connect();
        }
    }

    @Override
    protected void onStop(){
        super.onStop();
        if(mGoogleApiClient.isConnected()){
            mGoogleApiClient.disconnect();
        }
    }


    public void updateLiningColour(int c) {
        mImageView.setBackgroundColor(c);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onItemSelected(View view, int level, float deltaX, boolean isSwiping) {
        FragmentManager fragmentManager = getSupportFragmentManager();

        FragmentNewEntry em;

        if (level == 1 || level == 2) {
            mCurrentLevel = level;
            EmotionListViewItem emItem = (EmotionListViewItem) view;
            em = FragmentNewEntry.newInstance(emItem.getEmotionId(), level);

            FragmentTransaction ft = fragmentManager.beginTransaction();

            ft.setCustomAnimations(R.anim.slide_in_right, R.anim.slide_out_left);

            ft.replace(R.id.base_emotion_frame, em);
                ft.addToBackStack(FRAGMENT_LEVEL_PREFIX+mCurrentLevel);
            ft.commit();
//
//                if(mCurrentLevel == 1){
//                    em.setHighlightColor(emItem.getColor());
//                    mBaseColor = emItem.getColor();
//                } else {
//                    em.setHighlightColor(mBaseColor, emItem.getColor());
//                }

        }
    }

    @Override
    public void onClickBackView(int position, FlatColorListWithSwipeView listView) {

    }

    @Override
    public void onClickFrontView(int position, FlatColorListWithSwipeView listView) {
        EmotionListViewItem customListViewItem = (EmotionListViewItem) listView.getChildAt(position);

        if (customListViewItem != null) {
            final FrameLayout listItemFront = (FrameLayout) customListViewItem.findViewById(R.id.list_item_front);

            Animations.bounceMe(listItemFront);

        }
    }

    @Override
    public void onOpened(final int position, final FlatColorListWithSwipeView listView) {

        openedPosition = position;
        openedFlastColorListWithSwipeView = listView;

        //TODO
        //save in preferences when the last save was made
        //save in preferences what the last saved emotion id was
        //if the difference is less than 15 mins && last saved emotion id is the same
        //do not make this save
        //show a toast telling the user why they cannot save this!
        EmotionListViewItem customListViewItem = (EmotionListViewItem) listView.getChildAt(position);

        if (customListViewItem == null) return;

        ProgressBar progressBar = (ProgressBar) customListViewItem.findViewById(R.id.list_item_back_progress);
        final Button editButton = (Button) customListViewItem.findViewById(R.id.button_edit_entry);

        values = new ContentValues();
        values.put(EmotionContract.EmotionEntry.COLUMN_EMOTION_ID, customListViewItem.getEmotionId());

        if(mLastLocation != null){
            values.put(EmotionContract.EmotionEntry.COLUMN_COORD_LAT, mLastLocation.getLatitude());
            values.put(EmotionContract.EmotionEntry.COLUMN_COORD_LON, mLastLocation.getLongitude());
        } else {
            values.put(EmotionContract.EmotionEntry.COLUMN_COORD_LAT, "");
            values.put(EmotionContract.EmotionEntry.COLUMN_COORD_LON, "");
        }

        values.put(EmotionContract.EmotionEntry.COLUMN_CREATED_AT, Generic.getDateTime());



        values.put(EmotionContract.EmotionEntry.COLUMN_NOTE, "");
        values.put(EmotionContract.EmotionEntry.COLUMN_IMAGE, "");

        final Uri entryUri = getContentResolver().insert(EmotionContract.EmotionEntry.CONTENT_URI, values);
        final Colors.FlatColor viewColor = customListViewItem.getColor();

        Toast.makeText(this, getResources().getString(R.string.entry_added), Toast.LENGTH_SHORT).show();
        progressBar.setVisibility(View.GONE);
        editButton.setVisibility(View.VISIBLE);


        //when save is complete set up a listener on undo button
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ActivityNewEntry.this, ActivityEditEntry.class);
                intent.putExtra(ActivityEditEntry.URI, entryUri.toString());
                intent.putExtra(ActivityEditEntry.ALT_COLOR, viewColor.getAltColor());

                ActivityNewEntry.this.startActivity(intent);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                listView.closeAnimate(position);

            }
        });

        Toast.makeText(this, getResources().getString(R.string.entry_added), Toast.LENGTH_SHORT).show();
        progressBar.setVisibility(View.GONE);
        editButton.setVisibility(View.VISIBLE);

    }

    /** callbacks for google location stuff **/
    @Override
    public void onConnected(Bundle bundle) {
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
    }

    @Override
    public void onConnectionSuspended(int i) {
        mGoogleApiClient.connect();
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {

    }
}

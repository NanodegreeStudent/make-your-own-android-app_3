package co.msingh.android.fine.views;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.TextView;

import co.msingh.android.fine.R;
import co.msingh.android.fine.utilities.Colors;

/**
 * Created by mani on 11/03/15.
 */
public class EmotionListViewItem extends CustomListViewItemBase implements CustomListViewItemBase.FlatColorSettings {

    private int emotionId;
    private Colors.FlatColor color;

    public EmotionListViewItem(Context context) {
        super(context);
    }

    public EmotionListViewItem(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public EmotionListViewItem(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public EmotionListViewItem(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }


    public void setEmotionId(int id) {
        this.emotionId = id;
    }

    public int getEmotionId() {
        return this.emotionId;
    }


    @Override
    public void setFlatColor(Colors.FlatColor color) {
        this.color = color;
        this.altBackground();
        this.normBackground();
    }

    public Colors.FlatColor getColor() {
        return this.color;
    }

    public void altBackground() {
        if (this.color == null) return;
        FrameLayout fm = (FrameLayout) findViewById(R.id.list_item_back);
        fm.setBackgroundColor(getResources().getColor(this.color.getAltColor()));
    }

    public void normBackground() {
        if (this.color == null) return;
//        FrameLayout fm = (FrameLayout) findViewById(R.id.list_item_front);
//        fm.setBackgroundColor(getResources().getColor(this.color.getColor()));

        ((TextView) findViewById(R.id.list_item_emotion_textview))
                .setTextColor(getResources().getColor(color.getColor()));
        findViewById(R.id.divider).setBackgroundColor(getResources().getColor(color.getAltColor()));
    }
}

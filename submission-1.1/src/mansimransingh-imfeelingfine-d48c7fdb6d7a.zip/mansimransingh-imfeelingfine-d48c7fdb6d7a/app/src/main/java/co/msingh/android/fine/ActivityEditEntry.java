package co.msingh.android.fine;


import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.Editable;

public class ActivityEditEntry extends ActionBarActivity implements FragmentEditEntry.Callback {

    public static final String URI = "uri";
    public static final String ALT_COLOR = "flat_color";
    private final String FRAGMENT_TAG = "edit_entry_fragment";
    private boolean isSaved;
    private FragmentEditEntry fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_entry);

        if (savedInstanceState == null) {
            Bundle arguments = new Bundle();
            arguments.putString(
                    FragmentEditEntry.ENTRY_URI,
                    getIntent().getStringExtra(ActivityEditEntry.URI)
            );
            int color = getIntent().getIntExtra(ActivityEditEntry.ALT_COLOR, 0);
            arguments.putInt(FragmentEditEntry.FLAT_ALT_COLOR,color
                    );

            fragment = new FragmentEditEntry();
            fragment.setArguments(arguments);

            getSupportFragmentManager().beginTransaction()
                    .add(R.id.edit_entry_container, fragment, FRAGMENT_TAG)
                    .commit();
        }
        isSaved = false;
    }

    private void saveEntry() {
        if (isSaved) return;

        FragmentEditEntry fg = (FragmentEditEntry) getSupportFragmentManager().findFragmentByTag(FRAGMENT_TAG);

        if (fg != null) {
            fg.saveEntry();
        }
    }

    @Override
    public void onBackPressed() {
        FragmentEditEntry fg = (FragmentEditEntry) getSupportFragmentManager().findFragmentByTag(FRAGMENT_TAG);

        if(fg == null || fg.backPressed()) {
            super.onBackPressed();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        }
    }

    @Override
    public void onPause() {
        saveEntry();
        super.onPause();
    }

    @Override
    public void onEditTextChanged(Editable editText) {
        isSaved = false;
    }

    @Override
    public void isSaved(boolean isSaved) {
        this.isSaved = isSaved;
    }

}

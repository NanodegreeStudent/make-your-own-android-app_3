package co.msingh.android.fine.views;

import android.content.Context;
import android.util.AttributeSet;

import co.msingh.android.fine.swipelistview.SwipeListView;
import co.msingh.android.fine.utilities.Colors;


public class FlatColorListWithSwipeView extends SwipeListView implements FlatColorBase {

    public FlatColorListWithSwipeView(Context context, int swipeBackView, int swipeFrontView) {
        super(context, swipeBackView, swipeFrontView);
    }

    public FlatColorListWithSwipeView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public FlatColorListWithSwipeView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }


    private Colors.FlatColor color[];

    public void initColor() {
        if (color != null) return;
        this.color = Colors.getRandomisedColors();
    }

    public int getColor(int i) {
        initColor();
        return color[getValidIndex(i, color)].getColor();
    }

    public int getValidIndex(int i, Colors.FlatColor[] colors) {
        if (i < 0) {
            i = 0;
        }
        i = i % colors.length;
        return i;
    }

    public Colors.FlatColor getFlatColor(int i) {
        initColor();
        return color[getValidIndex(i, color)];
    }

    public int getAltColor(int i) {
        initColor();
        return color[getValidIndex(i, color)].getAltColor();
    }
}

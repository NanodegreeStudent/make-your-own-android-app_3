package co.msingh.android.fine.utilities;

import android.view.View;
import android.view.animation.BounceInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;

/**
 * Created by mani on 10/03/15.
 */
public class Animations {
    public static void bounceMe(final View view) {
        TranslateAnimation rightTranslation;
        rightTranslation = new TranslateAnimation(0, 300f, 0, 0);
        rightTranslation.setStartOffset(0);
        rightTranslation.setDuration(100);
        rightTranslation.setFillAfter(true);
        rightTranslation.setInterpolator(new LinearInterpolator());
        view.startAnimation(rightTranslation);
//
        view.postDelayed(new Runnable() {
            @Override
            public void run() {
                TranslateAnimation translation;
                translation = new TranslateAnimation(300f, 0, 0f, 0f);
                translation.setStartOffset(0);
                translation.setDuration(1000);
                translation.setFillAfter(true);
                translation.setInterpolator(new BounceInterpolator());
                view.startAnimation(translation);
            }
        }, 100);
    }
}

package co.msingh.android.fine;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBarActivity;
import android.text.Editable;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import java.util.Calendar;

import co.msingh.android.fine.data.EmotionContract;
import co.msingh.android.fine.utilities.Generic;
import co.msingh.android.fine.views.EntryListViewItem;
import co.msingh.android.fine.views.FloatingActionButton;


public class ActivityListEntry extends ActionBarActivity implements FragmentListEntry.Callbacks, FragmentEditEntry.Callback {
    private FloatingActionButton fabNewEntry;
//    private FloatingActionButton fabShowDatePicker;
//    private boolean isFabDatePickerShowing;
    private boolean twoPane;
    private boolean isSaved;
    private final String EDIT_FRAGMENT_TAG = "edit_entry_fragment";
    private final String VIEW_FRAGMENT_TAG = "view_entry_fragment";
    private final String LIST_FRAGMENT_TAG = "list_fragment";

    private int mSelectedInList;

    private int alarmInterval;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_entry);


        twoPane = false;

        if (savedInstanceState == null) {

            getSupportFragmentManager().beginTransaction()
                    .add(R.id.container, new FragmentListEntry(), LIST_FRAGMENT_TAG)
                    .commit();
        }

        if(findViewById(R.id.two_pane_fragment_container) != null){
            twoPane = true;
            isSaved = true;
        }


//        isFabDatePickerShowing = false;
        createNewEntryFab();

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        alarmInterval = Integer.parseInt(prefs.getString(getResources().getString(R.string.pref_notification_interval_key), "1"));

    }

    public void createNewEntryFab() {
        fabNewEntry = new FloatingActionButton.Builder(this)
                .withDrawable(getResources().getDrawable(R.drawable.ic_action_new))
                .withButtonColor(getResources().getColor(R.color.flat_navy_blue))
                .withMargins(16, 16, 16, 16)
                .withGravity(Gravity.BOTTOM | Gravity.RIGHT)
                .create();

//        fabShowDatePicker = new FloatingActionButton.Builder(this)
//                .withDrawable(getResources().getDrawable(R.drawable.ic_action_new))
//                .withButtonColor(getResources().getColor(R.color.flat_teal))
//                .withGravity(Gravity.BOTTOM | Gravity.RIGHT)
//                .withButtonSize(36)
//                .withMargins(0, 0, 16, 16 + 72)
//                .create(((FrameLayout)findViewById(R.id.container)));

//        hideFabDatePicker();

        fabNewEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ActivityListEntry.this, ActivityNewEntry.class);
                ActivityListEntry.this.startActivity(intent);
                overridePendingTransition(R.anim.grow_from_fab, R.anim.abc_fade_out);

//                hideFabDatePicker();
            }
        });

//        fabNewEntry.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                fabShowDatePicker.setVisibility(View.VISIBLE);
//                isFabDatePickerShowing = true;
//                return true;
//            }
//        });
    }

//    private void hideFabDatePicker() {
//        fabShowDatePicker.setVisibility(View.GONE);
//        isFabDatePickerShowing = false;
//    }




    @Override
    public void onResume(){
        super.onResume();
        if(findViewById(R.id.two_pane_fragment_container) == null){
            twoPane = false;

            FragmentEditEntry fg = (FragmentEditEntry) getSupportFragmentManager().findFragmentByTag(EDIT_FRAGMENT_TAG);

            if (fg != null) {
                fg.saveEntry();


                int id = fg.getEntryId();
                int color = fg.getColor();

                fg.removeFragment();

                startEditEntryWithIntent(
                        EmotionContract.EmotionEntry.buildEmotionEntryURI(id).toString(),
                        color);
            }
        } else {
            twoPane = true;
        }

        updateAlarm();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_list_entry, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent intent = new Intent(this, ActivitySettings.class );
            startActivity(intent);
            return true;
        } else if(id == R.id.action_send_feedback){

            Intent emailIntent = new Intent(
                    Intent.ACTION_SENDTO,
                    Uri.fromParts("mailto",
                            getResources().getString(R.string.mani_email),
                            null));

            emailIntent.putExtra(Intent.EXTRA_SUBJECT,
                    getResources().getString(R.string.email_subject_feedback));

            startActivity(Intent.createChooser(emailIntent,
                    getResources().getString(R.string.select_email_client)));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position) {
        EntryListViewItem entryListViewItem = (EntryListViewItem) view;

        mSelectedInList = position;
        viewEntry(entryListViewItem);

    }

    @Override
    public void onItemAlertDialogClick(AdapterView<?> parent, View view, int position, int action) {
        final EntryListViewItem entryListViewItem = (EntryListViewItem) view;

        mSelectedInList = position;

        switch(action){
            case FragmentListEntry.ALERT_ACTION_VIEW:
                viewEntry(entryListViewItem);
                break;
            case FragmentListEntry.ALERT_ACTION_EDIT:
                editEntry(entryListViewItem);
                break;
            case FragmentListEntry.ALERT_ACTION_DELETE:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);

                builder.setTitle(R.string.title_alert_delete);

                builder.setIcon(R.drawable.ic_action_discard_dark);

                builder.setMessage(R.string.message_alert_delete);

                builder.setPositiveButton(R.string.action_delete_button,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                deleteEntry(entryListViewItem.getEntryId());
                            }
                        });

                builder.setNegativeButton(R.string.action_cancel_button,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });

                builder.create().show();

                break;
        }
    }

    private void deleteEntry(long entryId){
        Uri uri = EmotionContract.EmotionEntry.buildEmotionEntryURI(entryId);

        int rowsAffected = getContentResolver().delete(uri, null, null);

        if(rowsAffected > 0){
            Toast.makeText(this, R.string.delete_success, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.delete_fail, Toast.LENGTH_SHORT).show();
        }
    }

    private void editEntry(EntryListViewItem entryListViewItem){
        String uri = EmotionContract.EmotionEntry.buildEmotionEntryURI(entryListViewItem.getEntryId()).toString();

        if(twoPane == true){
            addEditEntryFragment(uri, entryListViewItem.getFlatColor().getColor());
        } else {

            startEditEntryWithIntent(uri,
                    entryListViewItem.getFlatColor().getAltColor());

        }
    }

    private void viewEntry(EntryListViewItem entryListViewItem){
        String uri = EmotionContract.EmotionEntry.buildEmotionEntryURI(entryListViewItem.getEntryId()).toString();

        if(twoPane == true){
            addViewEntryFragment(uri, entryListViewItem.getFlatColor().getColor());
        } else {

            startViewEntryWithIntent(uri,
                    entryListViewItem.getFlatColor().getAltColor());

        }
    }

    private void startViewEntryWithIntent(String uri, int color){
        Intent intent = new Intent(ActivityListEntry.this, ActivityViewEntry.class);
        Log.d(Generic.LOG_TAG, "ENTRY URI: " + uri);

        intent.putExtra(ActivityViewEntry.URI, uri);

        intent.putExtra(ActivityViewEntry.ALT_COLOR, color);
//        intent.addFlags(intent.getFlags() | Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private void startEditEntryWithIntent(String uri, int color){
        Intent intent = new Intent(ActivityListEntry.this, ActivityEditEntry.class);
        Log.d(Generic.LOG_TAG, "ENTRY URI: " + uri);

        intent.putExtra(ActivityEditEntry.URI, uri);

        intent.putExtra(ActivityEditEntry.ALT_COLOR, color);
//        intent.addFlags(intent.getFlags() | Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private void addViewEntryFragment(String uri, int color) {
        Bundle arguments = new Bundle();
        arguments.putString(
                FragmentViewEntry.ENTRY_URI,
                uri
        );
        arguments.putInt(FragmentViewEntry.FLAT_ALT_COLOR, color);

        FragmentViewEntry fragment = new FragmentViewEntry();
        fragment.setArguments(arguments);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.two_pane_fragment_container, fragment, VIEW_FRAGMENT_TAG)
//                    .addToBackStack(null)
                .setCustomAnimations(R.anim.slide_in_right, R.anim.abc_fade_out)
                .commit();

        fabNewEntry.setVisibility(View.GONE);
        isSaved = false;
    }

    private void addEditEntryFragment(String uri, int color) {
            Bundle arguments = new Bundle();
            arguments.putString(
                    FragmentEditEntry.ENTRY_URI,
                    uri
            );
            arguments.putInt(FragmentEditEntry.FLAT_ALT_COLOR, color);

            FragmentEditEntry fragment = new FragmentEditEntry();
            fragment.setArguments(arguments);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.two_pane_fragment_container, fragment, EDIT_FRAGMENT_TAG)
//                    .addToBackStack(null)
                    .setCustomAnimations(R.anim.slide_in_right, R.anim.abc_fade_out)
                    .commit();

            fabNewEntry.setVisibility(View.GONE);
        isSaved = false;
    }

    public void onEditTextChanged(Editable s){
        this.isSaved = false;
    }

    @Override
    public void onBackPressed() {
//        if (isFabDatePickerShowing) {
//            hideFabDatePicker();
//            return;
//        }

        if(twoPane == true && isSaved == false){
            FragmentEditEntry fg = (FragmentEditEntry) getSupportFragmentManager().findFragmentByTag(EDIT_FRAGMENT_TAG);

            if (fg != null) {
                fg.saveEntry();
                fg.removeFragment();

                scrollToPosition();

                fabNewEntry.setVisibility(View.VISIBLE);

                return;
            }

        }

        super.onBackPressed();
    }

    public void scrollToPosition(){
        FragmentListEntry fl = (FragmentListEntry) getSupportFragmentManager().findFragmentByTag(LIST_FRAGMENT_TAG);

        if(fl != null && mSelectedInList != 0){
            fl.scrollTo(mSelectedInList);

            mSelectedInList = 0;
        }
    }

    public void isSaved(boolean isSaved){
        this.isSaved = isSaved;
    }

    private void updateAlarm(){

        //check if alarm exists
        boolean doesAlarmExist = (PendingIntent.getBroadcast(
                this, 0, new Intent(this, AlarmReceiver.class),
                PendingIntent.FLAG_NO_CREATE) != null);
        //get shared preference
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

        int interval = Integer.parseInt( prefs.getString(
                getResources().getString(R.string.pref_notification_interval_key), "1"));



        if(doesAlarmExist){
            //is interval different
            if(interval != alarmInterval){
                //cancel the alarm
                cancelAlarm();

                //set new alarm
                setNewAlarm(interval);
            }
        } else {
            setNewAlarm(interval);
        }

     }

    private void setNewAlarm(int interval){
        alarmInterval = interval;
        if(interval == 0){ //no notifications
            return;
        }
        PendingIntent sender = getAlarmIntent();
        AlarmManager am = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
        long recurring = (interval * 60 * 60000);  // hours in milliseconds
        am.setRepeating(AlarmManager.RTC, Calendar.getInstance().getTimeInMillis(), recurring, sender);


    }

    private void cancelAlarm(){
        AlarmManager am = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
        try {
            am.cancel(getAlarmIntent());
        } catch(Exception e){
            Toast.makeText(this, getResources().getString(R.string.failed_alarm_cancel),Toast.LENGTH_SHORT).show();
        }

        Log.d(Generic.LOG_TAG, " Cancelled alarm!");

    }

    private PendingIntent getAlarmIntent(){
        Intent intent = new Intent(this, AlarmReceiver.class);
        return PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
    }

}

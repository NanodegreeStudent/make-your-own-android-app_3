package co.msingh.android.fine;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import co.msingh.android.fine.data.EmotionContract;
import co.msingh.android.fine.utilities.Generic;
import co.msingh.android.fine.views.FlatColorListView;

/**
 * Created by mani on 11/03/15.
 */
public class FragmentListEntry extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {
    private static final int ENTRY_LOADER = 1;
    private static final String SELECTED_KEY = "selected";
    private static final int NUM_ON_INIT_VIEW = 8;
    public static final int ALERT_ACTION_VIEW = 0;
    public static final int ALERT_ACTION_EDIT = 1;
    public static final int ALERT_ACTION_DELETE = 2;

    private static final String[] ENTRY_COLUMNS = {
            EmotionContract.EmotionEntry.TABLE_NAME + "." + EmotionContract.EmotionEntry._ID,
            EmotionContract.EmotionEntry.COLUMN_EMOTION_ID,
            EmotionContract.EmotionEntry.COLUMN_CREATED_AT,
            EmotionContract.EmotionEntry.COLUMN_COORD_LAT,
            EmotionContract.EmotionEntry.COLUMN_COORD_LON,
            EmotionContract.EmotionEntry.COLUMN_NOTE,
            EmotionContract.Emotions.TABLE_NAME + "." + EmotionContract.Emotions.COLUMN_EMOTION_NAME,
    };

    static final int COL_ENTRY_ID = 0;
    static final int COL_EMOTION_ID = 1;
    static final int COL_CREATED_AT = 2;
    static final int COL_COORD_LAT = 3;
    static final int COL_COORD_LON = 4;
    static final int COL_NOTE = 5;
    static final int COL_EMOTION_NAME = 6;

    private AdapterListEntry mAdapterListEntry;
    private FlatColorListView mListView;
    private int mPosition;

    private float width;

    public FragmentListEntry() {
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        getLoaderManager().initLoader(ENTRY_LOADER, null, this);
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {



        mAdapterListEntry = new AdapterListEntry(getActivity(), null, 0);

        View rootView = inflater.inflate(R.layout.fragment_list_entry, container, false);


        mListView = (FlatColorListView) rootView.findViewById(R.id.listview_entries);
        mListView.setAdapter(mAdapterListEntry);

        if (savedInstanceState != null && savedInstanceState.containsKey(SELECTED_KEY)) {
            mPosition = savedInstanceState.getInt(SELECTED_KEY);
            scrollTo(mPosition);
        }


        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ((Callbacks) getActivity()).onItemClick(parent, view, position);
            }

        });

        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(final AdapterView<?> parent, final View view, final int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

                builder.setTitle(getString(R.string.title_list_entry_long_alert));

                builder.setItems(new CharSequence[]{
                        getString(R.string.view_text_alert),
                        getString(R.string.edit_text_alert),
                        getString(R.string.delete_text_alert),
                },
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ((Callbacks) getActivity()).onItemAlertDialogClick(parent, view, position, which);
                            }
                        });

                builder.show();
                return true;
            }
        });

        return rootView;
    }



    public interface Callbacks {
        void onItemClick(AdapterView<?> parent, View view, int position);
        void onItemAlertDialogClick(AdapterView<?> parent, View view, int position, int action);
    }

    public void scrollTo(int position){
        mListView.smoothScrollToPosition(position);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Uri emotionEntryUri = EmotionContract.EmotionEntry.CONTENT_URI;

        return new CursorLoader(getActivity(),
                emotionEntryUri,
                ENTRY_COLUMNS,
                null,
                null,
                EmotionContract.EmotionEntry.COLUMN_CREATED_AT + " DESC");
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        mAdapterListEntry.swapCursor(data);

        mAdapterListEntry.setHeight(Generic.getAvailableHeight(getActivity()) / NUM_ON_INIT_VIEW);

        if (mPosition != ListView.INVALID_POSITION) {
            mListView.smoothScrollToPosition(mPosition);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        mAdapterListEntry.swapCursor(null);
    }
}

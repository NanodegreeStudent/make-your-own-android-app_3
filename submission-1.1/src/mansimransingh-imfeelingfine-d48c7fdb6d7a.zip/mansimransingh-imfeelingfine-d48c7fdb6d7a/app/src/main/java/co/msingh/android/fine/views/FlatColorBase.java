package co.msingh.android.fine.views;

import co.msingh.android.fine.utilities.Colors;

/**
 * Created by mani on 11/03/15.
 */
abstract interface FlatColorBase {
    void initColor();

    int getColor(int i);

    int getValidIndex(int i, Colors.FlatColor[] colors);

    Colors.FlatColor getFlatColor(int i);

    int getAltColor(int i);
}
